package ai.unbound.app

import android.net.Uri
import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

private val Bg = Color(0xFF090A10)
private val Panel = Color(0xFF151722)
private val Accent = Color(0xFF9B7CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UnboundApp() }
    }
}

enum class AiMode(val label: String) {
    HYBRID("Гибрид"), LOCAL("Локально"), CLOUD("Облако")
}

data class ChatMessage(val role: String, val text: String)

@Composable
fun UnboundApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { HybridChatEngine() }
    var mode by remember { mutableStateOf(AiMode.HYBRID) }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Готов к работе") }
    var endpoint by remember { mutableStateOf("https://api.openai.com/v1/chat/completions") }
    var apiKey by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("gpt-4.1-mini") }
    var localUrl by remember { mutableStateOf("http://127.0.0.1:8080/v1/chat/completions") }
    var visionUrl by remember { mutableStateOf("http://127.0.0.1:8081/v1/chat/completions") }
    var visionModel by remember { mutableStateOf("local-vision") }
    var showSettings by remember { mutableStateOf(false) }
    var selectedImage by remember { mutableStateOf<ImageAttachment?>(null) }
    var imageLabel by remember { mutableStateOf<String?>(null) }
    var showImageGen by remember { mutableStateOf(false) }
    var imagePrompt by remember { mutableStateOf("") }
    var imageApiUrl by remember { mutableStateOf("https://api.openai.com/v1/images/generations") }
    var imageModel by remember { mutableStateOf("gpt-image-1") }
    var generatedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val messages = remember {
        mutableStateListOf(ChatMessage("assistant", "Привет. Я UNBOUND AI. Можешь написать сообщение или прикрепить фотографию."))
    }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val bitmap = context.contentResolver.openInputStream(uri).use { input ->
                    BitmapFactory.decodeStream(input)
                } ?: error("Не удалось прочитать изображение")
                val scaled = scaleBitmap(bitmap, 1280)
                val bytes = ByteArrayOutputStream().use { out ->
                    scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
                    out.toByteArray()
                }
                selectedImage = ImageAttachment("image/jpeg", android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP))
                imageLabel = "Фотография прикреплена"
            } catch (e: Exception) {
                imageLabel = "Не удалось открыть фото: ${e.message}"
                selectedImage = null
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("UNBOUND AI", style = MaterialTheme.typography.headlineSmall, color = Color.White)
                    Text(status, style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
                }
                TextButton(onClick = { showSettings = true }) { Text("Настройки") }
            }
            Spacer(Modifier.height(12.dp))
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                AiMode.entries.forEachIndexed { index, item ->
                    SegmentedButton(
                        selected = mode == item, onClick = { mode = item },
                        shape = SegmentedButtonDefaults.itemShape(index, AiMode.entries.size)
                    ) { Text(item.label) }
                }
            }
            Spacer(Modifier.height(12.dp))
            generatedBitmap?.let { bitmap ->
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Созданное изображение",
                    modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp),
                    contentScale = ContentScale.Fit
                )
                TextButton(onClick = { generatedBitmap = null }) { Text("Скрыть изображение") }
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.role == "user") Arrangement.End else Arrangement.Start) {
                        Surface(
                            color = if (msg.role == "user") Color(0xFF332B55) else Panel,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.widthIn(max = 320.dp)
                        ) { Text(msg.text, Modifier.padding(14.dp), color = Color.White) }
                    }
                }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            imageLabel?.let { Text(it, color = Color.LightGray, style = MaterialTheme.typography.labelSmall) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { showImageGen = true }, enabled = !busy) { Text("Создать изображение") }
                Spacer(Modifier.weight(1f))
            }
            Row(verticalAlignment = Alignment.Bottom) {
                OutlinedTextField(
                    value = draft, onValueChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Напиши сообщение…") }, maxLines = 5,
                    shape = RoundedCornerShape(18.dp)
                )
                Spacer(Modifier.width(6.dp))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    TextButton(onClick = { photoPicker.launch("image/*") }, enabled = !busy) { Text("Фото") }
                    Button(
                        enabled = !busy && (draft.isNotBlank() || selectedImage != null),
                        onClick = {
                            val prompt = draft.trim().ifBlank { "Опиши это изображение." }
                            val attachment = selectedImage
                            draft = ""
                            messages.add(ChatMessage("user", if (attachment != null) "$prompt\n[Фотография]" else prompt))
                            selectedImage = null
                            imageLabel = null
                            busy = true
                            scope.launch {
                                try {
                                    val answer = engine.reply(
                                        mode, messages.toList(), endpoint, apiKey, model,
                                        localUrl, attachment, visionUrl, visionModel
                                    )
                                    messages.add(ChatMessage("assistant", answer))
                                    status = "Ответ получен"
                                } catch (e: Exception) {
                                    messages.add(ChatMessage("assistant", "Ошибка: ${e.message ?: "не удалось получить ответ"}"))
                                    status = "Ошибка соединения"
                                } finally { busy = false }
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 16.dp)
                    ) { Text("➤") }
                }
            }
        }


        if (showImageGen) {
            AlertDialog(
                onDismissRequest = { showImageGen = false },
                title = { Text("Создать изображение") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Опиши изображение, которое нужно создать.")
                        OutlinedTextField(
                            value = imagePrompt,
                            onValueChange = { imagePrompt = it },
                            label = { Text("Описание изображения") },
                            minLines = 3,
                            maxLines = 6
                        )
                        Text(
                            "Генерация выполняется через облачный API. Для неё используется ключ из настроек облачного подключения.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.LightGray
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        enabled = imagePrompt.isNotBlank() && !busy,
                        onClick = {
                            val prompt = imagePrompt.trim()
                            showImageGen = false
                            busy = true
                            status = "Создаю изображение…"
                            scope.launch {
                                try {
                                    val bitmap = ImageGenerationEngine.generate(
                                        endpoint = imageApiUrl,
                                        apiKey = apiKey,
                                        model = imageModel,
                                        prompt = prompt
                                    )
                                    generatedBitmap = bitmap
                                    messages.add(ChatMessage("assistant", "Изображение создано по запросу: $prompt"))
                                    status = "Изображение готово"
                                    imagePrompt = ""
                                } catch (e: Exception) {
                                    messages.add(ChatMessage("assistant", "Не удалось создать изображение: ${e.message ?: "ошибка генерации"}"))
                                    status = "Ошибка генерации"
                                } finally { busy = false }
                            }
                        }
                    ) { Text("Создать") }
                },
                dismissButton = {
                    TextButton(onClick = { showImageGen = false }) { Text("Отмена") }
                }
            )
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Подключения") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("Облако (OpenAI-compatible)")
                        OutlinedTextField(endpoint, { endpoint = it }, label = { Text("Cloud URL") }, singleLine = true)
                        OutlinedTextField(apiKey, { apiKey = it }, label = { Text("API key") }, singleLine = true)
                        OutlinedTextField(model, { model = it }, label = { Text("Cloud model") }, singleLine = true)
                        Text("Генерация изображений")
                        OutlinedTextField(imageApiUrl, { imageApiUrl = it }, label = { Text("Image API URL") }, singleLine = true)
                        OutlinedTextField(imageModel, { imageModel = it }, label = { Text("Image model") }, singleLine = true)
                        Divider()
                        Text("Локальная текстовая модель")
                        OutlinedTextField(localUrl, { localUrl = it }, label = { Text("Text URL") }, singleLine = true)
                        Text("Локальная модель зрения")
                        OutlinedTextField(visionUrl, { visionUrl = it }, label = { Text("Vision URL") }, singleLine = true)
                        OutlinedTextField(visionModel, { visionModel = it }, label = { Text("Vision model ID") }, singleLine = true)
                        Text(
                            "Фото обрабатывается выбранным сервером. В гибридном режиме при ошибке локального сервера запрос с фото может уйти в облако. Для приватности выбери «Локально». Ключ в демо хранится только в памяти.",
                            style = MaterialTheme.typography.bodySmall, color = Color.LightGray
                        )
                    }
                },
                confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Готово") } }
            )
        }
    }
}

private fun scaleBitmap(source: Bitmap, maxSide: Int): Bitmap {
    val largest = maxOf(source.width, source.height)
    if (largest <= maxSide) return source
    val ratio = maxSide.toFloat() / largest
    return Bitmap.createScaledBitmap(
        source, (source.width * ratio).toInt(), (source.height * ratio).toInt(), true
    )
}
