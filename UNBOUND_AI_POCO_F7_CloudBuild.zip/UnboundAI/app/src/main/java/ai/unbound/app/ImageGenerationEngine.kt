package ai.unbound.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ImageGenerationEngine {
    fun generate(
        endpoint: String,
        apiKey: String,
        model: String,
        prompt: String
    ): Bitmap {
        require(endpoint.startsWith("https://") || endpoint.startsWith("http://")) {
            "Укажи корректный URL Image API"
        }
        require(apiKey.isNotBlank()) {
            "Для облачной генерации нужен API key. Добавь его в настройках."
        }

        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 240_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $apiKey")
        }

        val payload = JSONObject()
            .put("model", model)
            .put("prompt", prompt)
            .put("size", "1024x1024")
            .put("n", 1)

        try {
            connection.outputStream.use {
                it.write(payload.toString().toByteArray(Charsets.UTF_8))
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                throw IllegalStateException("Image API HTTP $code: ${responseText.take(600)}")
            }

            val data = JSONObject(responseText).getJSONArray("data").getJSONObject(0)
            val bitmap = if (data.has("b64_json") && !data.isNull("b64_json")) {
                val bytes = Base64.decode(data.getString("b64_json"), Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } else if (data.has("url") && !data.isNull("url")) {
                downloadBitmap(data.getString("url"))
            } else {
                null
            }
            return bitmap ?: throw IllegalStateException(
                "Провайдер не вернул изображение в формате b64_json или url"
            )
        } finally {
            connection.disconnect()
        }
    }

    private fun downloadBitmap(url: String): Bitmap? {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 120_000
        }
        try {
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("Не удалось скачать результат изображения")
            }
            return connection.inputStream.use { BitmapFactory.decodeStream(it) }
        } finally {
            connection.disconnect()
        }
    }
}
