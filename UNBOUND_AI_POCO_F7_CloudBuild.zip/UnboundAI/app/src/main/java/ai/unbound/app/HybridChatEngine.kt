package ai.unbound.app

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class ImageAttachment(
    val mimeType: String,
    val base64Data: String
)

class HybridChatEngine {
    suspend fun reply(
        mode: AiMode,
        history: List<ChatMessage>,
        cloudUrl: String,
        cloudKey: String,
        cloudModel: String,
        localUrl: String,
        image: ImageAttachment? = null,
        localVisionUrl: String = localUrl,
        localVisionModel: String = "local-vision"
    ): String = withContext(Dispatchers.IO) {
        val system = ChatMessage(
            "system",
            "Ты UNBOUND AI — прямой, любознательный и полезный ассистент. " +
                "Отвечай на языке пользователя, не морализируй и не выдумывай факты. " +
                "Уважай согласие, приватность и безопасность людей на изображениях."
        )
        val conversation = listOf(system) + history.takeLast(24)
        when (mode) {
            AiMode.LOCAL -> request(
                if (image != null) localVisionUrl else localUrl,
                "", if (image != null) localVisionModel else "local-model",
                conversation, image
            )
            AiMode.CLOUD -> request(cloudUrl, cloudKey, cloudModel, conversation, image)
            AiMode.HYBRID -> {
                try {
                    request(
                        if (image != null) localVisionUrl else localUrl,
                        "", if (image != null) localVisionModel else "local-model",
                        conversation, image
                    )
                } catch (_: Exception) {
                    request(cloudUrl, cloudKey, cloudModel, conversation, image)
                }
            }
        }
    }

    private fun request(
        endpoint: String,
        apiKey: String,
        model: String,
        history: List<ChatMessage>,
        image: ImageAttachment?
    ): String {
        require(endpoint.startsWith("http://") || endpoint.startsWith("https://")) {
            "Укажи корректный URL сервера"
        }
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 12_000
            readTimeout = 180_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            if (apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
        }

        val msgs = JSONArray()
        history.forEachIndexed { index, item ->
            val content: Any = if (index == history.lastIndex && image != null && item.role == "user") {
                JSONArray()
                    .put(JSONObject().put("type", "text").put("text", item.text))
                    .put(
                        JSONObject().put("type", "image_url").put(
                            "image_url",
                            JSONObject().put(
                                "url",
                                "data:${image.mimeType};base64,${image.base64Data}"
                            )
                        )
                    )
            } else item.text
            msgs.put(JSONObject().put("role", item.role).put("content", content))
        }

        val body = JSONObject()
            .put("model", model)
            .put("messages", msgs)
            .put("temperature", 0.8)
            .put("stream", false)

        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code: ${response.take(500)}")
            return JSONObject(response).getJSONArray("choices")
                .getJSONObject(0).getJSONObject("message").getString("content")
        } finally {
            connection.disconnect()
        }
    }
}
