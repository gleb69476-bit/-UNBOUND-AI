#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

MODEL="${HOME}/models/Qwen3-4B-Q4_K_M.gguf"
SERVER="${HOME}/bin/llama-server"

if [ ! -x "$SERVER" ]; then
  echo "Не найден исполняемый файл: $SERVER"
  echo "Соберите llama.cpp для Android arm64 по docs/POCO_F7_LOCAL_MODEL_RU.md"
  exit 1
fi

if [ ! -f "$MODEL" ]; then
  echo "Не найден файл модели: $MODEL"
  echo "Скачайте Qwen3-4B-GGUF Q4_K_M с официальной карточки Hugging Face."
  exit 1
fi

exec "$SERVER" \
  -m "$MODEL" \
  --host 127.0.0.1 \
  --port 8080 \
  -c 4096 \
  -ngl 99 \
  --jinja
